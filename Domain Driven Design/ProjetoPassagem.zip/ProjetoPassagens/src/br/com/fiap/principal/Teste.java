package br.com.fiap.principal;
import br.com.fiap.modelo.Escala;

public class Teste {

	public static void main(String[] args) {
		
		// Inst�nciando o Objeto Escala
		Escala objeto = new Escala("Cidade:" + " Osasco", "2/Horas");
		
		// Inserindo e Exibindo os Dados
		// objeto.setLocalidade("Cidade:" + " Osasco");
		System.out.println(objeto.getLocalidade());
		
		// Inserindo e Exibindo os Dados
		
		// objeto.setDuracao("2/Horas");
		System.out.println(objeto.getDuracao());
	}

}

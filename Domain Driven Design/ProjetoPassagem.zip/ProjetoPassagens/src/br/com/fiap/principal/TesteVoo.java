package br.com.fiap.principal;


// Imports
import br.com.fiap.modelo.Voo;
import br.com.fiap.modelo.Escala;

public class TesteVoo {

	public static void main(String[] args) {
		Voo voo = new Voo();
		
		voo.setDestino("Rio de Janeiro");
		voo.setDuracao("45 minutos");
		voo.setHorario("10h00");
		
		// Escala escala = new Escala("Guarulhos", "1hora");
		//escala.setDuracao("1hora");
		//escala.setLocalidade("Guarulhos");
		voo.setEscala(new Escala("Guarulhos", "1hora"));
		
		
		// N�o vou errar na prova
		// System.out.println(escala.getLocalidade());
		System.out.println("Localidade: " + voo.getEscala().getLocalidade());
		System.out.println("Destino: " + voo.getDestino());
		System.out.println("Dura��o: " + voo.getDuracao());
		System.out.println("Hor�rio: " + voo.getHorario());
		
		// A linha abaixo apresenta posi��o de memoria
		System.out.println(voo.getEscala());
	}
	
}

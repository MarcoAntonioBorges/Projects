package br.com.fiap.modelo;

public class Bacharelado extends Curso{

	private double cargaHorariaEstagio;
	private boolean estendido;
	private String projetoConclusao;

	
	public double exibirMensalidade() {
		if (estendido == true) {
			return super.getValor() / (super.getDuracao() + 12);
		}else {
			return super.getValor() / super.getDuracao();
		}
	}

	public String getAll() {
		return super.getAll() + "\n" + 
				"Carga Horaria Estagio....: " + cargaHorariaEstagio + "\n" +
				"Estendio....: " + estendido + "\n" + 
				"Projeto de Conclus�o....: " + projetoConclusao;
	}

	public void setAll(String descricao, String coordenacao, Unidade unidade, String sigla, int duracao, double valor,
			int cargaHorariaEstagio, boolean estendido, String projetoConclusao) {
		super.setAll(descricao, coordenacao, unidade, sigla, duracao, valor);
		setCargaHorariaEstagio(cargaHorariaEstagio);
		setEstendido(estendido);
		setProjetoConclusao(projetoConclusao);
	}


	public Bacharelado() {
		super();
	}


	public Bacharelado(String descricao, String coordenacao, Unidade unidade, String sigla, int duracao, double valor,
			double cargaHorariaEstagio, boolean estendido, String projetoConclusao) {
		super(descricao, coordenacao, unidade, sigla, duracao, valor);
		this.cargaHorariaEstagio = cargaHorariaEstagio;
		this.estendido = estendido;
		this.projetoConclusao = projetoConclusao;
	}

	public double getCargaHorariaEstagio() {
		return cargaHorariaEstagio;
	}
	public void setCargaHorariaEstagio(int cargaHorariaEstagio) {
		this.cargaHorariaEstagio = (cargaHorariaEstagio * 30)* 0.10;
	}
	public boolean isEstendido() {
		return estendido;
	}
	public void setEstendido(boolean estendido) {
		this.estendido = estendido;
	}
	public String getProjetoConclusao() {
		return projetoConclusao;
	}
	public void setProjetoConclusao(String projetoConclusao) {
		this.projetoConclusao = projetoConclusao.toLowerCase();
	}




}

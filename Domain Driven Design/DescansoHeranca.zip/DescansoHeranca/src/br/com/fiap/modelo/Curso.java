package br.com.fiap.modelo;

public class Curso {
	private String descricao;
	private String coordenacao;
	private Unidade unidade;
	private String sigla;
	private int duracao;
	private double valor;
	
	public double exibirMensalidade() {
		return getValor() / getDuracao();
	}
	
	public String getAll() {
		return "Descricao....: " + descricao + "\n" +
				"Coordenacao....: " + coordenacao + "\n" +
				unidade.getAll() + "\n" + 
				"Sigla....: " + sigla + "\n" +
				"Duracao....: " + duracao + "\n" +
				"valor....: " + valor;
	}
	
	public void setAll(String descricao, String coordenacao, Unidade unidade, String sigla, int duracao, double valor) {
		setDescricao(descricao);
		setCoordenacao(coordenacao);
		setUnidade(unidade);
		setSigla(sigla);
		setDuracao(duracao);
		setValor(valor);
	}
	
	public Curso() {
		super();
	}

	public Curso(String descricao, String coordenacao, Unidade unidade, String sigla, int duracao, double valor) {
		super();
		setDescricao(descricao);
		setCoordenacao(coordenacao);
		setUnidade(unidade);
		setSigla(sigla);
		setDuracao(duracao);
		setValor(valor);
	}
	
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao.toLowerCase();
	}
	public String getCoordenacao() {
		return coordenacao;
	}
	public void setCoordenacao(String coordenacao) {
		this.coordenacao = coordenacao.toLowerCase();
	}
	public Unidade getUnidade() {
		return unidade;
	}
	public void setUnidade(Unidade unidade) {
		this.unidade = unidade;
	}
	public String getSigla() {
		return sigla.toUpperCase();
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public int getDuracao() {
		return duracao;
	}
	public void setDuracao(int duracao) {
		this.duracao = duracao;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		if (valor > 0) {
			this.valor = valor;
		}else {
			this.valor = 1;
		}
	}
	
	
	
}

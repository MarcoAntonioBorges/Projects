package br.com.fiap.modelo;

public class Unidade {

	private String nome;
	private String fone;
	private String email;
	
	public String getAll() {
		return "Nome....: " + nome + "\n" +
				"Telefone....: " + fone + "\n" +
				"Email....: " + email;
	}
	
	public void setAll(String nome, String fone, String email) {
		setNome(nome);
		setFone(fone);
		setEmail(email);
	}
	
	
	public Unidade() {
		super();
	}

	public Unidade(String nome, String fone, String email) {
		super();
		setNome(nome);
		setFone(fone);
		setEmail(email);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		if (nome.length() < 20) {
			this.nome = nome.toLowerCase();
		}else {
			this.nome = nome.substring(0, 20);
		}
	}
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone.toLowerCase();
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		if((email.indexOf("@")>2) && (email.indexOf(".")>2)) {
			this.email = email;
		}else {
			this.email = "email@fiap.com.br";
		}
	}
	
	
	
}

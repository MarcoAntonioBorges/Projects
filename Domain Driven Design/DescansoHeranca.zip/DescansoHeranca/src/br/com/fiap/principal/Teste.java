package br.com.fiap.principal;

import br.com.fiap.modelo.Bacharelado;
import br.com.fiap.modelo.Unidade;
import br.com.fiap.view.Magica;

public class Teste {
	public static void main(String[] args){
		Bacharelado bacharelado_01 = new Bacharelado();
		
		bacharelado_01.setAll(Magica.texto("Digite a descri��o do curso"), Magica.texto("Digite o nome do coordenador do curso"), new Unidade(Magica.texto("Digite a unidade do curso"),Magica.texto("Digite o telefone"),Magica.texto("Digite o email")), Magica.texto("Digite a sigla do curso"), Magica.inteiro("Digite a carga horaria"), Magica.inteiro("Digite o valor do curso"),
				Magica.inteiro("Digite a carga horaria do curso"), Magica.booleano("Plano estendido?"), Magica.texto("Nome do projeto"));
		System.out.println(bacharelado_01.getAll());
		
		
		
	}
}

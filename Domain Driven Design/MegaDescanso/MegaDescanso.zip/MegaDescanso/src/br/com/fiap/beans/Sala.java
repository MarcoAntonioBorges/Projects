package br.com.fiap.beans;

public class Sala {
	private int numeroSala;
	private int numeroAndar;
	private int quantidadeCapacidade;
	private String observacao;
	
	public String getAll() {
		return "/n" + "Numero da Sala....: " + numeroSala + "\n" + "Numero do andar....: " + numeroAndar + "\n" + 
				"Quantidade....: " + quantidadeCapacidade + "\n" + "Observacao....: " + observacao;
	}
	
	public void setAll(int numeroSala, int numeroAndar, int quantidadeCapacidade, String observacao) {
		setNumeroSala(numeroSala);
		setNumeroAndar(numeroAndar);
		setQuantidadeCapacidade(quantidadeCapacidade);
		setObservacao(observacao);
	}
	
	public Sala() {
		super();
	}

	public Sala(int numeroSala, int numeroAndar, int quantidadeCapacidade, String observacao) {
		super();
		setNumeroSala(numeroSala);
		setNumeroAndar(numeroAndar);
		setQuantidadeCapacidade(quantidadeCapacidade);
		setObservacao(observacao);
	}
	
	public int getNumeroSala() {
		return numeroSala;
	}
	public void setNumeroSala(int numeroSala) {
		this.numeroSala = numeroSala;
	}
	public int getNumeroAndar() {
		return numeroAndar;
	}
	public void setNumeroAndar(int numeroAndar) {
		this.numeroAndar = numeroAndar;
	}
	public int getQuantidadeCapacidade() {
		return quantidadeCapacidade;
	}
	public void setQuantidadeCapacidade(int quantidadeCapacidade) {
		this.quantidadeCapacidade = quantidadeCapacidade;
	}
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao.toUpperCase();
	}

	
	
}

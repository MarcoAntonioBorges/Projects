package br.com.fiap.beans;

public class Exame {
	private int codigoAvaliacao;
	private Aluno aluno;
	private Medico medico;
	private String dataAvaliacao;
	private double valorPressao;
	private int qtdBatimento;
	private double valorAltura;
	private double valorPeso;
	private String observacao;
	
	
	public String getAll() {
		return aluno.getAll() + "\n" + medico.getAll() + "\n" + "Codigo avaliacao....: " + codigoAvaliacao + "\n" + "Data da Avalia��o....: " + dataAvaliacao + "\n" +
				"Valor Press�o....: " + valorPressao + "\n" + "Quantidade do Batimento....: " + qtdBatimento + "\n" +
				"Valor da Altura....: " + valorAltura + "\n" + "Valor do peso....: " + valorPeso + "\n" + "Observa��o....: " + observacao;
	}
	
	public void setAll(Aluno aluno, Medico medico, int codigoAvaliacao, String dataAvaliacao, double valorPressao, int qtdBatimento,
			double valorAltura, double valorPeso, String observacao) {
		setAluno(aluno);
		setMedico(medico);
		setCodigoAvaliacao(codigoAvaliacao);
		setDataAvaliacao(dataAvaliacao);
		setValorPressao(valorPressao);
		setQtdBatimento(qtdBatimento);
		setValorAltura(valorAltura);
		setValorPeso(valorPeso);
		setObservacao(observacao);
	}
	
	public Exame() {
		super();
	}

	public Exame(Aluno aluno, Medico medico, int codigoAvaliacao, String dataAvaliacao, double valorPressao, int qtdBatimento,
			double valorAltura, double valorPeso, String observacao) {
		super();
		setAluno(aluno);
		setMedico(medico);
		setCodigoAvaliacao(codigoAvaliacao);
		setDataAvaliacao(dataAvaliacao);
		setValorPressao(valorPressao);
		setQtdBatimento(qtdBatimento);
		setValorAltura(valorAltura);
		setValorPeso(valorPeso);
		setObservacao(observacao);
	}
	
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public Medico getMedico() {
		return medico;
	}
	public void setMedico(Medico medico) {
		this.medico = medico;
	}
	public String getDataAvaliacao() {
		return dataAvaliacao;
	}
	public void setDataAvaliacao(String dataAvaliacao) {
		this.dataAvaliacao = dataAvaliacao.toUpperCase();
	}
	public double getValorPressao() {
		return valorPressao;
	}
	public void setValorPressao(double valorPressao) {
		this.valorPressao = valorPressao;
	}
	public int getQtdBatimento() {
		return qtdBatimento;
	}
	public void setQtdBatimento(int qtdBatimento) {
		this.qtdBatimento = qtdBatimento;
	}
	public double getValorAltura() {
		return valorAltura;
	}
	public void setValorAltura(double valorAltura) {
		this.valorAltura = valorAltura;
	}
	public double getValorPeso() {
		return valorPeso;
	}
	public void setValorPeso(double valorPeso) {
		this.valorPeso = valorPeso;
	}
	public String getObservacao() {
		return observacao;
	}
	public void setObservacao(String observacao) {
		this.observacao = observacao.toUpperCase();
	}

	public int getCodigoAvaliacao() {
		return codigoAvaliacao;
	}

	public void setCodigoAvaliacao(int codigoAvaliacao) {
		this.codigoAvaliacao = codigoAvaliacao;
	}
	
	
	
}

package br.com.fiap.beans;

public class Aluno extends PFisicaAcademia{
	private Instituicao instituicao;
	private String dataMatricula;
	
	
	public double calcularMensalidade(double valorMensalidade) {
		/*if(instituicao.getValorDesconto() > 0){*/
		if(instituicao != null) {
			return valorMensalidade - (valorMensalidade * (instituicao.getValorDesconto()/100));
		}else {
			return valorMensalidade;
		}
	}
	
	public String getAll() {
		return super.getAll() + "\n" + instituicao.getAll() + "Data da matricula....: " + dataMatricula;
	}
	
	public void setAll(int numeroMatriucla, String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg,
			String dataNascimeto, char sexo, Instituicao instituicao, String dataMatricula) {
		super.setAll(numeroMatriucla, nome, endereco, email, telefone, cpf, rg, dataNascimeto, sexo);
		setInstituicao(instituicao);
		setDataMatricula(dataMatricula);
	}
	
	public Aluno() {
		super();
	}



	public Aluno(int numeroMatriucla, String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg,
			String dataNascimeto, char sexo, Instituicao instituicao, String dataMatricula) {
		super(numeroMatriucla, nome, endereco, email, telefone, cpf, rg, dataNascimeto, sexo);
		setInstituicao(instituicao);
		setDataMatricula(dataMatricula);
	}



	public Instituicao getInstituicao() {
		return instituicao;
	}
	public void setInstituicao(Instituicao instituicao) {
		this.instituicao = instituicao;
	}
	public String getDataMatricula() {
		return dataMatricula;
	}
	public void setDataMatricula(String dataMatricula) {
		this.dataMatricula = dataMatricula.toUpperCase();
	} 
	
	
}

package br.com.fiap.beans; 

public class Instituicao extends Pessoa{
	private int codigo;
	private String nomeContato;
	private String cnpj;
	private String url;
	private double valorDesconto;

	public String getAll() {
		return super.getAll() + "\n" + "Codigo....: " + codigo + "\n"  + "Nome contato....: " + nomeContato + "\n" +
				"CNPJ....: " + cnpj + "\n" + "URL....: " + url + "\n" + 
				"Valor Percentual Desconto....: " + valorDesconto; 
	} 

	public void setAll(int codigo, String nome, Endereco endereco, String email, Telefone telefone, String nomeContato, String cnpj,
			String url, double valorDesconto) {
		super.setAll(nome, endereco, email, telefone);
		setCodigo(codigo);
		setNome(nomeContato);
		setCnpj(cnpj);;
		setUrl(url);
		setValorDesconto(valorDesconto);
	}

	public Instituicao() {
		super();
	}


	public Instituicao(int codigo, String nome, Endereco endereco, String email, Telefone telefone, String nomeContato, String cnpj,
			String url, double valorDesconto) {
		super(nome, endereco, email, telefone);
		setCodigo(codigo);
		setNome(nomeContato);
		setCnpj(cnpj);;
		setUrl(url);
		setValorDesconto(valorDesconto);
	}


	public String getNomeContato() {
		return nomeContato;
	}
	public void setNomeContato(String nomeContato) {
		this.nomeContato = nomeContato.toUpperCase();
	}
	public String getCnpj() {
		return cnpj;
	}
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj.toUpperCase();
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url.toLowerCase();
	}
	public double getValorDesconto() {
		return valorDesconto;
	}
	public void setValorDesconto(double valorDesconto) {
		this.valorDesconto = valorDesconto;
	}

	public double getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

}

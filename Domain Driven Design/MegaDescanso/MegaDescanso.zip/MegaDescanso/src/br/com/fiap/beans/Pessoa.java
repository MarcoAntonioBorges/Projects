package br.com.fiap.beans;

public class Pessoa {
	private String nome;
	private Endereco endereco;
	private String email;
	private Telefone telefone;
	
	public String getPrimeiraMetade() {
		return "\n" + "Logradouro....: " + endereco.getLogradouro() + "\n" +
				"Numero....: " + endereco.getNumero() + "\n" +
				"CEP....: " + endereco.getCep();
	}
	
	public String getPrimeiroNome() {
		return nome.substring(0, nome.indexOf(" "));
	}
	
	public String getAll() {
		return "\n" + "Nome....: " + nome + "\n" +
				"Email....: " + email + "\n" + endereco.getAll() + telefone.getAll(); 
	}
	
	public void setAll(String nome, Endereco endereco, String email, Telefone telefone) {
		setNome(nome);
		setEndereco(endereco);
		setEmail(email);
		setTelefone(telefone);
	}
	
	public Pessoa() {
		super();
	}


	public Pessoa(String nome, Endereco endereco, String email, Telefone telefone) {
		super();
		setNome(nome);
		setEndereco(endereco);
		setEmail(email);
		setTelefone(telefone);
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome.toUpperCase();
	}
	public Endereco getEndereco() {
		return endereco;
	}
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email.toLowerCase();
	}
	public Telefone getTelefone() {
		return telefone;
	}
	public void setTelefone(Telefone telefone) {
		this.telefone = telefone;
	}
	
	
	
}

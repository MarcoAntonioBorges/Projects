package br.com.fiap.beans;

public class Medico extends Funcionario{
	private String crm;

	public void setAll(String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg, String cargo,
			double salario, int cargaHorariaSemanal, String crm) {
		super.setAll(nome, endereco, email, telefone, cpf, rg, cargo, salario, cargaHorariaSemanal);
		setCrm(crm);
	}

	
	public String getAll() {
		return super.getAll() + "/n" + "CRM....: " + crm;
	}
	
	/* Construtores */
	public Medico(String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg, String cargo,
			double salario, int cargaHorariaSemanal, String crm) {
		super(nome, endereco, email, telefone, cpf, rg, cargo, salario, cargaHorariaSemanal);
		setCrm(crm);
	}
		
	public Medico() {
		super();
	}


	public String getCrm() {
		return crm;
	}

	public void setCrm(String crm) {
		this.crm = crm.toUpperCase();
	}
	
	
	
}

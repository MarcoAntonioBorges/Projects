package br.com.fiap.beans;

public class PessoaFisica extends Pessoa{
	/*
	 * rg
	 * cpf
	 * 
	 * */
	
	private String cpf;
	private String rg;
	
	public int getQtdeCpf() {
		return cpf.length();
	}
	
	public String getAll() {
		return "\n" + super.getAll() + "CPF....: " + cpf + "\n" +
				"RG....: " + rg;
	}
	
	public void setAll(String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg) {
		super.setAll(nome, endereco, email, telefone);
		setCpf(cpf);
		setRg(rg);
	}
	
	public PessoaFisica() {
		super();
	}


	public PessoaFisica(String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg) {
		super(nome, endereco, email, telefone);
		setCpf(cpf);
		setRg(rg);
	}
	
	
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf.toUpperCase();
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg.toUpperCase();
	}
}

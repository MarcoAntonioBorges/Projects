package br.com.fiap.teste;

import br.com.fiap.beans.Aluno;
import br.com.fiap.beans.Endereco;
import br.com.fiap.beans.Instituicao;
import br.com.fiap.beans.PFisicaAcademia;
import br.com.fiap.beans.Pessoa;
import br.com.fiap.beans.PessoaFisica;
import br.com.fiap.beans.Telefone;

public class Academia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Instanciar Academia e Modalidade
		 * 
		 * 
		 * */
		
		/* Teste de m�todos */
		
		// Instanciando a classe pessoa
		Pessoa pessoa_01 = new Pessoa();
		
		/*  GET - Primeiro Nome */
		pessoa_01.setNome("Marco Antonio Borges Oliveira");
		System.out.println(pessoa_01.getPrimeiroNome());
		
		/* GET - Metade Endereco */
		pessoa_01.setEndereco(new Endereco("Rua", 12, "4545455454", "Bairro", "Cidade"));
		System.out.println(pessoa_01.getPrimeiraMetade());
		
		
		/* Pessoa Fisica */
		PessoaFisica pessoaF_01 = new PessoaFisica();
		pessoaF_01.setCpf("446.254.468-48");
		System.out.println(pessoaF_01.getQtdeCpf());
		
		/* Pessoa Fisica Academia */
		PFisicaAcademia pessoa_academia = new PFisicaAcademia();
		pessoa_academia.setSexo('r');
		System.out.println(pessoa_academia.getSexo());
		
		/* Aluno */
		Aluno aluno_01 = new Aluno();
		aluno_01.setInstituicao(new Instituicao(2, "nome", new Endereco("sads", 12, "", "", ""), "sadsad@gmail.com", new Telefone(656, 5454, 5454), "Nome_Contato", "CNPJ",
			"www.GOOGLE.com.br", 10));
		System.out.println(aluno_01.calcularMensalidade(100));
	}

}

package br.com.fiap.beans;

public class Modalidade {
	private int codigo;
	private String modalidade;
	private String dataInicio;
	private String dataTermino;
	
	public String getAll() {
		return "\n" + "Codigo....: " + codigo + "\n" +  "Modalidade....: " + modalidade + "\n" +
				"Data inicio....: " + dataInicio + "\n";
	}
	
	public void setAll(int codigo, String modalidade, String dataInicio, String dataTermino) {
		setCodigo(codigo);
		setModalidade(modalidade);
		setDataInicio(dataInicio);
		setDataTermino(dataTermino);
	}
	
	
	public Modalidade() {
		super();
	}

	public Modalidade(int codigo, String modalidade, String dataInicio, String dataTermino) {
		super();
		setCodigo(codigo);
		setModalidade(modalidade);
		setDataInicio(dataInicio);
		setDataTermino(dataTermino);
	}
	
	public String getModalidade() {
		return modalidade;
	}
	public void setModalidade(String modalidade) {
		this.modalidade = modalidade.toUpperCase();
	}
	public String getDataInicio() {
		return dataInicio;
	}
	public void setDataInicio(String dataInicio) {
		this.dataInicio = dataInicio.toUpperCase();
	}
	public String getDataTermino() {
		return dataTermino;
	}
	public void setDataTermino(String dataTermino) {
		this.dataTermino = dataTermino.toUpperCase();
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	
	
	
}

package br.com.fiap.beans;

public class Funcionario extends PessoaFisica{
	private String cargo;
	private double salario;
	private int cargaHorariaSemanal;
	
	/*My Methods*/
	
	/*getAll*/
	public String getAll() {
		return "\n" + super.getAll() + "\n" + "Cargo....: " + cargo + "\n" +
				"Sa�rio....: " + salario + "\n" + "Carga Horaria....: " + cargaHorariaSemanal;
	}
	
	/*setAll*/
	public void setAll(String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg,
			String cargo, double salario, int cargaHorariaSemanal) {
		super.setAll(nome, endereco, email, telefone, cpf, rg);
		setCargo(cargo);
		setSalario(salario);
		setCargaHorariaSemanal(cargaHorariaSemanal);
	}
	
	/* End My Methods */
	
	/*Construtores*/
	
	/*VOID*/
	public Funcionario() {
		super();
	}
	
	/* FULL */
	public Funcionario(String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg,
			String cargo, double salario, int cargaHorariaSemanal) {
		super(nome, endereco, email, telefone, cpf, rg);
		setCargo(cargo);
		setSalario(salario);
		setCargaHorariaSemanal(cargaHorariaSemanal);
	}

	/*GETTER�s and SETTER�s*/
	public String getCargo() {
		return cargo;
	}
	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public int getCargaHorariaSemanal() {
		return cargaHorariaSemanal;
	}
	public void setCargaHorariaSemanal(int cargaHorariaSemanal) {
		this.cargaHorariaSemanal = cargaHorariaSemanal;
	}
	
	
	
}

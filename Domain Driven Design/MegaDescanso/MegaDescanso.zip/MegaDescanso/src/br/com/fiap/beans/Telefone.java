package br.com.fiap.beans;

public class Telefone {
	private int numero;
	private int ddd;
	private int codigoPais;
	
	public String getAll() {
		return "\n" + "Numero....: " + numero + "\n" +
				"DDD....: " + ddd + "\n" + "Codigo pais....: " + codigoPais;
	}
	
	public void setAll(int numero, int ddd, int codigoPais) {
		setNumero(numero);
		setDdd(ddd);
		setCodigoPais(codigoPais);
	}
	
	public Telefone() {
		super();
	}

	public Telefone(int numero, int ddd, int codigoPais) {
		super();
		setNumero(numero);
		setDdd(ddd);
		setCodigoPais(codigoPais);
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public int getDdd() {
		return ddd;
	}

	public void setDdd(int ddd) {
		this.ddd = ddd;
	}

	public int getCodigoPais() {
		return codigoPais;
	}

	public void setCodigoPais(int codigoPais) {
		this.codigoPais = codigoPais;
	}

	
	
}

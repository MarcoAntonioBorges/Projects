package br.com.fiap.beans;

public class Aula {
	private int codigoSequencial;
	private Modalidade modalidade;
	private Sala sala;
	private int numeroNivelDificuldade;
	private String dataHorarioInicio;
	private int numeroTempoDuracao;
	
	
	public String getAll() {
		return "\n" + modalidade.getAll() + "\n" + sala.getAll() + "\n" + "N� sequencial Aula....: " + codigoSequencial + "Nivel de dificuldade....: " + numeroNivelDificuldade + 
				"\n" + "Data e Hora (inicio)....: " + dataHorarioInicio + "\n" + "Dura��o....: " + numeroTempoDuracao;
	}
	
	public void setAll(Modalidade modalidade, Sala sala, int codigoSequencial,  int numeroNivelDificuldade, String dataHorarioInicio,
			int numeroTempoDuracao) {
		setModalidade(modalidade);
		setSala(sala);
		setCodigoSequencial(codigoSequencial);
		numeroNivelDificuldade(numeroNivelDificuldade);
		setDataHorarioInicio(dataHorarioInicio);
		setNumeroTempoDuracao(numeroTempoDuracao);
	}
	
	public Aula() {
		super();
	}


	public Aula(Modalidade modalidade, Sala sala, int numeroNivelDificuldade, String dataHorarioInicio,
			int numeroTempoDuracao) {
		super();
		setModalidade(modalidade);
		setSala(sala);
		setCodigoSequencial(codigoSequencial);
		numeroNivelDificuldade(numeroNivelDificuldade);
		setDataHorarioInicio(dataHorarioInicio);
		setNumeroTempoDuracao(numeroTempoDuracao);
	}
	
	
	public Modalidade getModalidade() {
		return modalidade;
	}
	public void setModalidade(Modalidade modalidade) {
		this.modalidade = modalidade;
	}
	public Sala getSala() {
		return sala;
	}
	public void setSala(Sala sala) {
		this.sala = sala;
	}
	public int getNumeroNivelDificuldade() {
		return numeroNivelDificuldade;
	}
	public void numeroNivelDificuldade(int numeroNivelDificuldade) {
		this.numeroNivelDificuldade = numeroNivelDificuldade;
	}
	public String getDataHorarioInicio() {
		return dataHorarioInicio;
	}
	public void setDataHorarioInicio(String dataHorarioInicio) {
		this.dataHorarioInicio = dataHorarioInicio.toUpperCase();
	}
	public int getNumeroTempoDuracao() {
		return numeroTempoDuracao;
	}
	public void setNumeroTempoDuracao(int numeroTempoDuracao) {
		this.numeroTempoDuracao = numeroTempoDuracao;
	}

	public int getCodigoSequencial() {
		return codigoSequencial;
	}

	
	public void setCodigoSequencial(int codigoSequencial) {
		this.codigoSequencial = codigoSequencial;
	}

	public void setNumeroNivelDificuldade(int numeroNivelDificuldade) {
		this.numeroNivelDificuldade = numeroNivelDificuldade;
	}
	
	
	
}

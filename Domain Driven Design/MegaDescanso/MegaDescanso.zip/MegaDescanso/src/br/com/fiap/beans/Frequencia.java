package br.com.fiap.beans;

public class Frequencia {
	private Aula aula;
	private ProfModalidade profModalidade;
	private Aluno aluno;
	private String dataAula;
	
	public String getAll() {
		return aula.getAll() + profModalidade.getAll() + aluno.getAll() + "\n" + "Data da Aula....: " + dataAula;
	}
	
	public void setAll(Aula aula, ProfModalidade profModalidade, Aluno aluno, String dataAula) {
		setAula(aula);
		setProfModalidade(profModalidade);
		setAluno(aluno);
		setDataAula(dataAula);
	}
	
	public Frequencia() {
		super();
	}

	public Frequencia(Aula aula, ProfModalidade profModalidade, Aluno aluno, String dataAula) {
		super();
		setAula(aula);
		setProfModalidade(profModalidade);
		setAluno(aluno);
		setDataAula(dataAula);
	}
	
	public Aula getAula() {
		return aula;
	}
	public void setAula(Aula aula) {
		this.aula = aula;
	}
	public ProfModalidade getProfModalidade() {
		return profModalidade;
	}
	public void setProfModalidade(ProfModalidade profModalidade) {
		this.profModalidade = profModalidade;
	}
	public Aluno getAluno() {
		return aluno;
	}
	public void setAluno(Aluno aluno) {
		this.aluno = aluno;
	}
	public String getDataAula() {
		return dataAula;
	}
	public void setDataAula(String dataAula) {
		this.dataAula = dataAula.toUpperCase();
	}
	
	
}

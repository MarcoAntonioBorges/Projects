package br.com.fiap.beans;

public class PFisicaAcademia extends PessoaFisica{
	private int numeroMatriucla;
	private String dataNascimeto;
	private char sexo;
	
	
	public String getAll() {
		return "\n" + super.getAll() + "\n" + "Data de Nascimento....: " + dataNascimeto + "\n" +
				"Sexo....: " + sexo;
	}
	
	public void setAll(int numeroMatriucla, String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg,
			String dataNascimeto, char sexo) {
		super.setAll(nome, endereco, email, telefone, cpf, rg);
		setDataNascimeto(dataNascimeto);
		setSexo(sexo);
		setNumeroMatriucla(numeroMatriucla);
	}
	
	
	public PFisicaAcademia() {
		super();
	}



	public PFisicaAcademia(int numeroMatriucla, String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg,
			String dataNascimeto, char sexo) {
		super(nome, endereco, email, telefone, cpf, rg);
		setDataNascimeto(dataNascimeto);
		setSexo(sexo);
		setNumeroMatriucla(numeroMatriucla);
	}



	public String getDataNascimeto() {
		return dataNascimeto;
	}
	public void setDataNascimeto(String dataNascimeto) {
		this.dataNascimeto = dataNascimeto.toUpperCase();
	}
	public char getSexo() {
		return sexo;
	}
	public void setSexo(char sexo) {
		if(sexo == 'M') {
			this.sexo = 'M';
		}else {
			this.sexo = 'F';
		}
	}

	public int getNumeroMatriucla() {
		return numeroMatriucla;
	}

	public void setNumeroMatriucla(int numeroMatriucla) {
		this.numeroMatriucla = numeroMatriucla;
	}
	
	
	
}

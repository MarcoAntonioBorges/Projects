package br.com.fiap.beans;

public class Professor extends PFisicaAcademia{
	private String apelido;

	
	public String getAll() {
		return super.getAll() + "\n" + "Apelido....: " + apelido;	
	}
	
	public void setAll(int numeroMatriucla, String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg,
			String dataNascimeto, char sexo, String apelido) {
		super.setAll(numeroMatriucla, nome, endereco, email, telefone, cpf, rg, dataNascimeto, sexo);
		setApelido(apelido);
	}
	
	public Professor() {
		super();
	}



	public Professor(int numeroMatriucla, String nome, Endereco endereco, String email, Telefone telefone, String cpf, String rg,
			String dataNascimeto, char sexo, String apelido) {
		super(numeroMatriucla, nome, endereco, email, telefone, cpf, rg, dataNascimeto, sexo);
		setApelido(apelido);
	}


	public String getApelido() {
		return apelido;
	}

	public void setApelido(String apelido) {
		this.apelido = apelido.toUpperCase();
	}
	
	
	
	
}

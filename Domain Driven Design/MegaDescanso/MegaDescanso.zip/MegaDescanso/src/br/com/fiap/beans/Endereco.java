package br.com.fiap.beans;

public class Endereco {
	private String logradouro;
	private int numero;
	private String cep;
	private String cidade;
	private String bairro;
	
	
	public String getAll() {
		return "\n" + "Logradouro....: " + logradouro + "\n" +
				"Numero....: " + numero + "\n" + "CEP....: " + cep + "\n" +
				"Cidade....: " + cidade + "\n" + "Bairro....: " + bairro;
	} 
	
	public void setAll(String logradouro, int numero, String cep, String cidade, String bairro) {
		setLogradouro(logradouro);
		setNumero(numero);
		setCep(cep);
		setCidade(cidade);
		setBairro(bairro);
	}
	
	
	public Endereco() {
		super();
	}


	public Endereco(String logradouro, int numero, String cep, String cidade, String bairro) {
		super();
		setLogradouro(logradouro);
		setNumero(numero);
		setCep(cep);
		setCidade(cidade);
		setBairro(bairro);
	}
	
	
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		if(!(logradouro.equalsIgnoreCase("R")) && !(logradouro.equalsIgnoreCase("RUA")) && !(logradouro.equalsIgnoreCase("AVENIDA")) && !(logradouro.equalsIgnoreCase("AV")) && !(logradouro.equalsIgnoreCase("AV")) && !(logradouro.equalsIgnoreCase("VIELA")) && !(logradouro.equalsIgnoreCase("PRA�A")) && !(logradouro.equalsIgnoreCase("P�"))){
			this.logradouro = "LOGRADOURO INVALIDO";
		}else {
			this.logradouro = logradouro.toUpperCase();
		}
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep.toUpperCase();
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade.toUpperCase();
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro.toUpperCase();
	}
	
	
	
}

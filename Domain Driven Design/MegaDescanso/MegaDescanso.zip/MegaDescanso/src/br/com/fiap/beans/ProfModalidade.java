package br.com.fiap.beans;

public class ProfModalidade {
	public Modalidade modalidade;
	public Professor professor;
	public String dataAptoModalidade;
	
	public String getAll() {
		return modalidade.getAll() + "\n" + professor.getAll() + "Data da Modalidade....: " + dataAptoModalidade;
	}
	
	public void setAll(Modalidade modalidade, Professor professor, String dataAptoModalidade) {
		setModalidade(modalidade);
		setProfessor(professor);
		setDataAptoModalidade(dataAptoModalidade);
	}
	
	public ProfModalidade() {
		super();
	}

	public ProfModalidade(Modalidade modalidade, Professor professor, String dataAptoModalidade) {
		super();
		setModalidade(modalidade);
		setProfessor(professor);
		setDataAptoModalidade(dataAptoModalidade);
	}
	
	public Modalidade getModalidade() {
		return modalidade;
	}
	public void setModalidade(Modalidade modalidade) {
		this.modalidade = modalidade;
	}
	public Professor getProfessor() {
		return professor;
	}
	public void setProfessor(Professor professor) {
		this.professor = professor;
	}
	public String getDataAptoModalidade() {
		return dataAptoModalidade;
	}
	public void setDataAptoModalidade(String dataAptoModalidade) {
		this.dataAptoModalidade = dataAptoModalidade.toUpperCase();
	}
	
	
	
	
}

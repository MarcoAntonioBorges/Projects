package br.com.fiap.principal;

import br.com.fiap.modelo.Fabricante;
import br.com.fiap.modelo.Produto;

public class Teste {
	public static void main(String[] args) {
		
		Produto produto = new Produto();
		
		produto.setCodigo(1);
		produto.setDescricao("Revista para colorir");
		produto.setValor(25.50);
		
		produto.setFabricante(new Fabricante("8454545-545", "XPTO"));
		
		System.out.println(produto.getAll());
		
		
		
		System.out.println("C�digo: " + produto.getCodigo());
		System.out.println("Descri��o: " + produto.getDescricao());
		System.out.println("Valor: " + produto.getValor());
		System.out.println("CNPJ: " + produto.getFabricante().getCnpj());
		System.out.println("Raz�o Social: " + produto.getFabricante().getRazaoSocial());
		
		
		// Usando o setAll
		
		Fabricante f = new Fabricante();
		f.setAll("123456", "Chave SA");
		Produto p2 = new Produto();
		p2.setAll(2, "Mouse", 50, f);
		System.out.println(p2.getAll());
		
		System.out.println(p2.getDesconto());
		
		System.out.println("----------- GET BASICO E SET BASICO-----------");
		Produto p3 = new Produto();
		p3.setBasico("Mesa", 22.50);
		System.out.println(p3.getBasico());
		
		System.out.println("----------- SET AUMENTO DE VALOR-----------");
		Produto p4 = new Produto();
		p4.setValor(50);
		System.out.println(p4.workerAumento(50));
	}
}

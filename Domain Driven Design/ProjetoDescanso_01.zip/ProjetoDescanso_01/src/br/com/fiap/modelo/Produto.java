package br.com.fiap.modelo;

public class Produto {
	private int codigo;
	private String descricao;
	private double valor;
	private Fabricante fabricante;
	
	
	// Aumentando o valor do produto "%"
	
	public String workerAumento(double aumento) {
		this.valor = this.valor + this.valor * (aumento/100);
		return "Valor alterado.....:" + this.valor + "\n" + "valor alterado";
	}
	
	
	public void setAll(int c, String d, double v, Fabricante f) {
		this.codigo = c;
		this.descricao = d;
		this.valor = v;
		this.fabricante = f;
	}
	
	public Double getDesconto() {
		return this.valor - (this.valor * 0.10);
	}	
	
	public void setBasico(String d, Double v) {
		descricao = d;
		valor = v;
	}
	
	public String getBasico() {
		return "Descricao...: " + descricao + "\n" +
				"Valor....: " + valor;
	}
	
	public String getAll () {
	 return "Codigo....:" + codigo + "\n" + 
			 "Descri��o....:" +   descricao + "\n" + 
			 "Valor....:" + valor + "\n" + 
			 "Fabricante....:" + "\n" + fabricante.getAll();
	}
	
	public Produto() {}
	
	public Produto(int codigo, String descricao, double valor, Fabricante fabricante) {
		this.codigo = codigo;
		this.descricao = descricao;
		this.valor=valor;
		this.fabricante=fabricante;
	}
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public Fabricante getFabricante() {
		return fabricante;
	}
	public void setFabricante(Fabricante fabricante) {
		this.fabricante = fabricante;
	}

}

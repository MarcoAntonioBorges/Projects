package br.com.fiap.modelo;

public class Curso {

	// Atributos
	private String nome;
	private String sigla;
	private String titulacao;

	public void setAll(String n, String s, String t) {
		this.nome = n;
		this.sigla = s;
		this.titulacao = t;
	}
	
	public String getAll() {
		return "NOME....:" + nome + "\n" + 
		"SIGLA....:" + sigla + "\n" +
		"TITULACAO....:" + titulacao + "\n" ;
	}

	// M�todos
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSigla() {
		return sigla;
	}
	public void setSigla(String sigla) {
		this.sigla = sigla;
	}
	public String getTitulacao() {
		return titulacao;
	}
	public void setTitulacao(String titulacao) {
		this.titulacao = titulacao;
	}



}

package br.com.fiap.principal;

import br.com.fiap.modelo.Aluno;
import br.com.fiap.modelo.Curso;

public class Teste {
	public static void main(String args[]) {
		Aluno aluno01 = new Aluno();
		Curso curso01 = new Curso();
		
		curso01.setAll("Java", "JV", "JAVA");
		aluno01.setAll("Marco", "81207", 10, 10, 10, 0, curso01);
		
		System.out.println(aluno01.getAll());
		
		System.out.println("MEDIA: " + aluno01.getMedia());
		
		aluno01.setFalta();
		
		System.out.println("FALTAS: " + aluno01.getFalta());
		System.out.println("STATUS: " + aluno01.getStatus());
	}
}

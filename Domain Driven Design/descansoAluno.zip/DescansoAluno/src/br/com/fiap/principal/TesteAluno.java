package br.com.fiap.principal;

import br.com.fiap.view.Magica;

import br.com.fiap.modelo.Aluno;
import br.com.fiap.modelo.Curso;

public class TesteAluno {
	
	public static void main(String args[]) {
		String email = new String();
		String nome = null;
		double numero;
			
		
		if (nome.length() < 2 || nome.length()>8) {
			System.out.println("ERROR Junin");
		}
		
		email = "MARCO.EMAILTESTE@GMAIL.COM".toLowerCase();
		if (email.indexOf("@")<2) {
			System.out.println("EMAIL INVALIDO");
		}
		
		System.out.println(email.substring(0,email.indexOf("@")));
		System.out.println(email.substring(email.indexOf("@")));
		
		System.out.println(nome + "\n " + email);
		
		Aluno a = new Aluno();
		
		//pedindo para o usuario digitar
		// JOptionPane classe 
		
		// Metodo 
		/* a.setNome(JOptionPane.showInputDialog("Nome do aluno"));
		 a.setRm(JOptionPane.showInputDialog("RM"));*/
		
		// Usando m�todo statico
		a.setNome(Magica.texto("Nome do Aluno"));
		a.setRm(Magica.texto("RM"));
		
		/*
		a.setPs(Double.parseDouble(JOptionPane.showInputDialog("Nota PS")));
		a.setAm(Double.parseDouble(JOptionPane.showInputDialog("Nota AM")));
		a.setNac(Double.parseDouble(JOptionPane.showInputDialog("Nota NAC")));
		a.setFalta(Integer.parseInt(JOptionPane.showInputDialog("Faltas")));
		*/
		
		// usando metodo statico
		a.setPs(Magica.decimal("Nota PS"));
		a.setAm(Magica.decimal("Nota AM"));
		a.setNac(Magica.decimal("Nota NAC"));
		a.setFalta(Magica.inteiro("Faltas"));
		
		// Instanciando o Obj Curso
		Curso c = new Curso();
		
		// Setando os valores nos atributos
		//c.setNome(JOptionPane.showInputDialog("Nome do curso"));
		//c.setTitulacao(JOptionPane.showInputDialog("Titula��o do curso"));
		//c.setSigla(JOptionPane.showInputDialog("Sigla do curso"));
		
		c.setNome(Magica.texto("Nome do curso"));
		c.setTitulacao(Magica.texto("Titula��o do curso"));
		c.setSigla(Magica.texto("Sigla do curso"));
		
		a.setCurso(c);
		
		System.out.println(a.getAll());
		System.out.println(a.getMedia());
		System.out.println(a.getStatus());
	}
}

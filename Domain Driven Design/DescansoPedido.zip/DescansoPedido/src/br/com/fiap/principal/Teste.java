package br.com.fiap.principal;

// IMPORTS
import br.com.fiap.modelo.Cliente;
import br.com.fiap.modelo.ItemPedido;
import br.com.fiap.modelo.Pedido;
import br.com.fiap.modelo.Produto;

public class Teste {
	public static void main(String[] args) {
		
		
		System.out.println("--------------------------- CONSTRUTORES ---------------------------");
		System.out.println("--------------------------------------------------------------------");
		System.out.println("");
		
		// CLIENTE
		System.out.println("--------- CLIENTE ---------");
		Cliente cliente_01 = new Cliente("Marco Antonio", "marco@gmail.com", "aaaaaaaaa", "123", 45);
		System.out.println(cliente_01.getAll());
		
		System.out.println("");
		
		//PRODUTO
		System.out.println("--------- PRODUTO ---------");
		Produto produto_01 = new Produto("Bola", 2.50, -100);

		System.out.println(produto_01.getAll());
		
		System.out.println("");
		
		//PEDIDO
		System.out.println("--------- PEDIDO ---------");
		Pedido pedido = new Pedido(1, new Cliente("Marco", "marcogmail.com", "marco", "senha123", 500), 35, "Cart�o de Cr�dito");
		System.out.println(pedido.getAll());
		
		System.out.println("");
		
		//ITEM PEDIDO
		System.out.println("--------- ITEM PEDIDO ---------");
		ItemPedido itemPedido = new ItemPedido(new Produto("Bolacha", 15.8, 1), 2, 10);
		System.out.println(itemPedido.getAll());
	
		System.out.println("");
		
		
	
	
		
		
		// TESTES DOS METODOS CRIADOS
		System.out.println("getSubtotal()...: " + itemPedido.getSubTotal());
		System.out.println("getPrimeiroNome()...: " + cliente_01.getPrimeiroNome());
		System.out.println("getResumo()...: " + produto_01.getResumo());
		System.out.println("getServidor()...: " + cliente_01.getServe());
		System.out.println("getUser()...: " + cliente_01.getUser());
		
		// Aumentar
		produto_01.setAumentar(10);
		System.out.println("aumentar()...: " + produto_01.getValor());		
	}
}

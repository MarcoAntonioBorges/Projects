package br.com.fiap.principal;

import br.com.fiap.modelo.Cliente;
import br.com.fiap.modelo.ItemPedido;
import br.com.fiap.modelo.Pedido;
import br.com.fiap.modelo.Produto;
import br.com.fiap.view.Magica;

public class TesteJOptionPane {
	public static void main(String[] args) {
		System.out.println("--------------------------- JOptionPane ---------------------------");
		System.out.println("--------------------------------------------------------------------");
		System.out.println("");
		
		// CLIENTE	
		System.out.println("--------- CLIENTE ---------");

		Cliente cliente_02 = new Cliente();
		
		// Nome
		cliente_02.setNome(Magica.texto("Nome"));
		System.out.println("Cliente......:" + cliente_02.getNome());
		
		//Email
		cliente_02.setEmail(Magica.texto("Email"));
		System.out.println("EMAIL......:" + cliente_02.getEmail());
		
		// Login
		cliente_02.setLogin(Magica.texto("Login"));
		System.out.println("LOGIN......:" + cliente_02.getLogin());
		
		// Senha
		cliente_02.setSenha(Magica.texto("Senha"));
		System.out.println("Senha......:" +  cliente_02.getSenha());
		
		//Estrelas
		cliente_02.setQtdEstrelas(Magica.inteiro("Quantidade de estrelas"));
		System.out.println("QTDE ESTRELAS......:" + cliente_02.getQtdEstrelas());
		
		System.out.println("");
		
		// PRODUTO	
		System.out.println("--------- PRODUTO ---------");
		
		// Instanciando o obj
		Produto produto_02 = new Produto();
		
		//Descricao
		produto_02.setDescricao(Magica.texto("Descricao"));
		System.out.println("DESCRICAO......:" + produto_02.getDescricao());
		
		//Valor
		produto_02.setValor(Magica.decimal("Valor"));
		System.out.println("VALOR......:" + produto_02.getValor());
		
		//Codigo
		produto_02.setCodigo(Magica.inteiro("Codigo"));
		System.out.println("CODIGO......:" + produto_02.getCodigo());
		
		System.out.println("");
		
		// PEDIDO	
		System.out.println("--------- PEDIDO ---------");
		
		// Instanciando o obj
		Pedido pedido_02 = new Pedido();
		
		//N� Pedido
		pedido_02.setNumPedido(Magica.inteiro("N� do pedido"));
		System.out.println("N� Pedido.....: " + pedido_02.getNumPedido());
		
		//Cliente
		pedido_02.setCliente(new Cliente(Magica.texto("Nome"), Magica.texto("Email"), Magica.texto("Login"), Magica.texto("Senha"), Magica.inteiro("Quantidade de estrelas")));
		System.out.println(pedido_02.getCliente().getAll());
		
		//Total
		pedido_02.setTotal(Magica.decimal("Total a pagar"));
		System.out.println("TOTAL.......:" + pedido_02.getTotal());
		
		//Forma de Pagamento
		pedido_02.setFormaPagamento(Magica.texto("Forma de Pagamento"));
		System.out.println("FORMA PAGAMENTO......: " + pedido_02.getFormaPagamento());
		
		System.out.println("");
		
		// Item pedido	
		System.out.println("--------- ITEM PEDIDO ---------");
		
		// Instanciando o obj
		ItemPedido itemPedido_02 = new ItemPedido();
		
		//Produto
		itemPedido_02.setProduto(new Produto(Magica.texto("Descricao"), Magica.decimal("Valor do produto"), Magica.inteiro("Codigo do produto")));
		System.out.println(itemPedido_02.getProduto().getAll());
		
		//Quantidade do produto
		itemPedido_02.setQtde(Magica.inteiro("Quantidade do produto"));
		System.out.println("QTDE......:" + itemPedido_02.getQtde());
		
		itemPedido_02.setValor(Magica.decimal("Valor do produto"));
		System.out.println("Valor......:" + itemPedido_02.getValor());
	}
}

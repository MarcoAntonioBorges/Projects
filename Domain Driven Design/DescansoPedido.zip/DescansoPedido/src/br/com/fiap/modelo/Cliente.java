package br.com.fiap.modelo;

public class Cliente {
	private String nome;
	private String email;
	private String  login;
	private String  senha;
	private int  qtdEstrelas;
	
	
	
	public void setAll(String nome, String email, String login, String senha, int qtdEstrelas) {
		setNome(nome);
		setEmail(email);
		setLogin(login);
		setSenha(senha);
		setQtdEstrelas(qtdEstrelas);
	}
	
	public String getUser() {
		return getEmail().substring(0, email.indexOf("@"));
	}
	
	public String getServe() {
		return getEmail().substring(email.indexOf("@"));
	}
	
	public String getPrimeiroNome() {
		return getNome().substring(0, nome.indexOf(" "));
	}	
	
	public String getAll() {
		return "Cliente......:" + this.nome + "\n" +
				"EMAIL......:" + this.email + "\n" +
				"LOGIN......:" + this.login + "\n" +
				"SENHA......:" + this.senha + "\n" +
				"QTDE ESTRELAS......:" + this.qtdEstrelas;
	}	
	
	public Cliente() {
		super();
	}
	
	public Cliente(String nome, String email, String login, String senha, int qtdEstrelas) {
		super();
		setNome(nome);
		setEmail(email);
		setLogin(login);
		setSenha(senha);
		setQtdEstrelas(qtdEstrelas);
	}
	
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome.toUpperCase();
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		if (email.length() > 80) {
			this.email = "ERRO Junnin";
		}
		if((email.indexOf("@")>2) && (email.indexOf(".")>2)) {
			this.email = email;
		}else {
			this.email = "ERRO Junnin";
		}
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		if ((login.length() > 8) && (login.length() <= 15)) {
			this.login = login.toUpperCase();
		}else {
			this.login = "ERRO Junnin";
		}
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		if ((senha.length() > 8) && (senha.length() <= 15)) {
			this.senha = senha.toUpperCase();
		}else {
			this.senha = "ERRO Junnin";
		}
	}
	public int getQtdEstrelas() {
		return qtdEstrelas;
	}
	public void setQtdEstrelas(int qtdEstrelas) {
		if((qtdEstrelas > 0) && (qtdEstrelas <= 5)) {
			this.qtdEstrelas = qtdEstrelas;
		}else {
			this.qtdEstrelas = 0;
		}
	}
}



package br.com.fiap.modelo;

public class Produto {
	private String descricao;
	private double valor;
	private int codigo;
	
	//MEUS METODOS
	public void setAumentar(double porc) {
		this.valor = this.valor + (this.valor * (porc/100));
	}
	
	
	// SetAll
	public void setAll(String descricao, double valor, int codigo) {
		setDescricao(descricao);
		setValor(valor);
		setCodigo(codigo);
	}
	
	public String getResumo() {
		return getDescricao().substring(0, getDescricao().length()/2);
	}
	
	public String getAll() {
		return "DESCRICAO......:" + this.descricao + "\n" +
				"VALOR......:" + this.valor + "\n" +
				"CODIGO......:" + this.codigo;
	}
	
	
	// Construtor
	public Produto() {
		super();
	}

	public Produto(String descricao, double valor, int codigo) {
		super();
		setDescricao(descricao);
		setValor(valor);
		setCodigo(codigo);
	}

	
	// SETTERS E GETTERS 
	
	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao.toUpperCase();
	}

	public double getValor() {
		return valor;
	}

	public void setValor(double valor) {
		if (valor > 0) {
			this.valor = valor;
		}else {
			this.valor = 0;
		}
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		if (codigo > 0) {
			this.codigo = codigo;
		}else {
			this.codigo = 0;
		}
	}
	
	
	
	
}

package com.andreymasiero.gerenciador.empresas.dao;

import java.util.HashMap;
import java.util.Map;

import com.andreymasiero.gerenciador.empresas.bean.Usuario;

public class UsuarioDAO {
	private final static Map<String, Usuario> USUARIOS = new HashMap<>();
	static {
		USUARIOS.put("marco@gmail.com", new Usuario("marco@gmail.com", "123"));
		USUARIOS.put("root@root.com", new Usuario("root@root.com", "123"));
	}

	public Usuario buscaPorEmailESenha(String email, String senha) {
		if (!USUARIOS.containsKey(email))
			return null;

		Usuario usuario = USUARIOS.get(email);
		if (usuario.getSenha().equals(senha))
			return usuario;

		return null;
	}
	
	public void adiciona(Usuario u) {
		USUARIOS.put(u.getEmail(), u);
	}
}

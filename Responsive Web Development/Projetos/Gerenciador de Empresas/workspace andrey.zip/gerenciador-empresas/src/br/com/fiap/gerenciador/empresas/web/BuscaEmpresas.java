package br.com.fiap.gerenciador.empresas.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.andreymasiero.gerenciador.empresas.bean.Empresa;
import com.andreymasiero.gerenciador.empresas.dao.EmpresaDAO;

/* URL => Para sempre pode tratar requisi��o por essa url,
 * ou seja, tudo que tiver url do projeto mais /busca ele cai nesse arquivo
 * dai tratamos o que precisa ser tratado */
@WebServlet(urlPatterns = {"/busca", "/cadastro/empresa"})
/* CRIANDO UM OBJ DE URL, PODENDO ADICIONAR MAIS URLs PARA A MESMA SERVLET */
/* herdando os atributos do HttpServlet para podermos monta
 * a nossa servlet */
public class BuscaEmpresas extends HttpServlet{
	/*
	 * TRATAR TODAS AS REQUISI��ES VINDA DO FRONTEND
	 * NOSSO ORQUESTRADOR/CONTROLLER 
	 * PEGA INFORMA��ES DO FRONTEND PASSA PARA O BACKEND
	 * BACKEND TRATA ESSES DADOS, EXCUTA AS FUN��ES PARA
	 * 'CONECTAR NO BANCO DE DADOS' O BANCO DE DADOS
	 * RETORNA AS INFORMA��ES REQUISITADAS, AP�S ISSO ELE
	 * VOLTA A RESPOSTA PARA O NOSSO CLIENTE QUE � O FRONTEND
	 * */
	@Override
	/* PRECISO DO DOGET PARA TRATAR REQUISI��ES DO TIPO GET
	 * PODENDO PEGAR O QUE O USUARIO QUER E RESPONDER O MESMO */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {		
		
		/* VARIAVEL PARA CONTROLAR O FILTRO DA BUSCA */
		String filtro = req.getParameter("filtro");
		
		/*  CHAMANDO O OBJ PRINTWRITER J� DO OBJ PRONTO QUE � O resp PARA PODER RETORNA UMA RESPOSTA PARA
		 * O CLIENTE NO FORMATO DE HTML  */
		PrintWriter writer = resp.getWriter();
		
		
		/* FAZENDO UM ARRAY DE Cookie PARA ARMAZENAR ALGUMA INFORMA��ES MUITO IMPORTANTE
		 * COMO NESSE CASO O LOGIN DO USUARIO PARA AUTENTICA��O */
		Cookie[] cookies = req.getCookies();
			
		/* INICIANDO MEU DOCUMENTO HTML PARA RESPOSTA AO MEU CLIENTE */
		writer.println("<html><body>");
		
		/* VERIFICANDO SE � NULO, OU SEJA, VERIFICANDO SE O CLIENTE EST� LOGADO NO SISTEMA */
		if(cookies != null) {
			
			/* CRIANDO UMA VARIAVEL PARA RECEBER O EMAIL DO USUARIO PARA FAZER UMA TELA DE BEM VINDO
			 * DIFERENCIADA PARA CADA USUARIO */
			String usuario = "";
			
			/* PERCORRENDO O MEU ARRAY DE COOKIE PARA PODE PEGAR O MEU COOKIE ONDE ESTA O MEU USUARIO LOGADO */
			for(Cookie cookie : cookies) {
				if(cookie.getName().equals("usuario")) {
					/* CASO O COOKIE QUE ESTIVER PASSANDO FOR IGUAL A USUARIO ELE PEGA O VALOR DO COOKIE
					 * E ARMAZENA NA VARIAVEL usuario */
					usuario = cookie.getValue();
				}
			}
			
			/* FAZENDO A MENSAGEM DE BEM VINDO DIFERENCIADA */
			writer.println("Bem vindo " + usuario);
			/* MOSTRANDO O RESULTADO DA BUSCA PELO USUARIO */
			writer.println("Resultado da busca: ");
			
			/* INSTANCIANDO A CLASSE DAO */
			EmpresaDAO empresaDao = new EmpresaDAO();
			/* RETORNA UMA LISTA DO BANCO DE DADOS, ATRAVES DO METODO
			 * buscaPorSimililaridade, ela retorna um array */
			/* ISSO VEM DA CLASSE EmpresaDAO */
			Collection <Empresa> empresas = empresaDao.buscaPorSimilaridade(filtro);
			
			/*PERCORRENDO O ARRAY VINDO DO BANCO DE DADOS FALSO */
			writer.println("<ul>");
			/* FOREACH  PARA PERCORRER CADA ITEM DO MEU ARRAY*/
			for(Empresa empresa : empresas) {
				writer.println("<li>" + empresa.getNome() + "</li>");
			}
			/* FECHANDO A MINHA LISTA COM ITENS DA BUSCA */
			writer.println("</ul>");
			
			
			
		}else {
			/* CASO O USUARIO N�O ESTEJA LOGADO ELE N�O PODER� REALIZAR A BUSCA DE EMPRESAS */
			writer.println("Voc� precisa estar logado");
			writer.println("<a href='login.html'>Logar</a>");
		}
		
		/* FECHANDO O MEU DOCUMENTO HTML  */
		writer.println("</body></html>");
	
		//Sempre fechar o writer
		writer.close();
	}
	
	
	/* AQUI ESTOU PEGANDO O POST ENVIADO DO MEU CLIENTE
	 * NESSE CASO TEM UM FORMULARIO QUE TEM A PROPRIEDADE action="cadastrar/empresa" E COM OUTRA PROPRIEDADE
	 * method="POST" QUANDO O CLIENTE ENVIAR ESSA REQUISI��O ELE CAIRA EXTAMENTE AQUI
	 * EXECUTANDO ESSA PARTE DO CODIGO*/
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		/* PEGANDO O PARAMETRO VINDO DO CLIENTE E ARMAZENANDO ISSO NA VARIAVEL */
		String nomeEmpresa = req.getParameter("nomeEmpresa");
		
		/* CRIANDO O MEU OBJ PARA CRIAR RESPOSTA EM HTML PARA O MEU CLIENTE */
		PrintWriter writer = resp.getWriter();
		
		/* INSTANCIANDO O MEU DAO DE EMPRESA */
		EmpresaDAO dao = new EmpresaDAO();
		
		/* INSTANCIANDO A MINHA CLASSE DE EMPRESA PASSANDO O VALOR DO PARAMETRO VINDO DO 
		 * MEU CLIENTE NO CONSTRUTOR DA CLASSE PARA REALIZAR O CADASTRO DA EMPRESA */
		Empresa empresa = new Empresa(nomeEmpresa);
		
		/*USUANDO O METODO DE ADICIONAR A EMPRESA ENVIADO DO MEU CLIENTE*/
		dao.adiciona(empresa);

		/* DANDO A RESPOSTA AO CLIENTE COM A MENSAGEM DE CADASTRO COM SUCESSO */
		writer.println("<html><body>");
		writer.println("<p>Cadastro com sucesso</p>");
		writer.println("<a href='../index.html'>Buscar empresas</a>");
		writer.println("</body></html>");
		/* FINALIZANDO A RESPOSTA EM HTML  */
		
		//Sempre fechar o writer
		writer.close();
	}
}

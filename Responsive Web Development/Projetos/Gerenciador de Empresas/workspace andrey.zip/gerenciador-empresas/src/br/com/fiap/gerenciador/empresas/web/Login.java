package br.com.fiap.gerenciador.empresas.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.andreymasiero.gerenciador.empresas.bean.Usuario;
import com.andreymasiero.gerenciador.empresas.dao.UsuarioDAO;


/* CLASSE PARA FAZER O LOGIN */

/* TODA SERVLET PRECISA DE UMA URL */

@WebServlet(urlPatterns="/login")

/* TODA CLASSE SERVLET HERDA DO HttpServlet */
public class Login extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		/* PEGANDO DADOS VINDO DO CLIENTE NO FORMULARIO */
		String email = req.getParameter("email");
		String senha = req.getParameter("senha");
		
		
		/* IMPORTANDO DO PACOTE DAO */
		UsuarioDAO dao = new UsuarioDAO();
		
		/* IMPORTANDO DO PACOTE BEANS */
		/* VERIFICANDO SE O EMAIL E SENHA QUE O CLIENTE INFORMOU � VALIDO OU N�O
		 * CASO SEJA VALIDO ELE RETORNA UM OBJ DE USUARIO, CASO N�O SEJA VALIDO ELE RETORNA
		 * NULL */
		Usuario usuario = dao.buscaPorEmailESenha(email, senha);
		
		PrintWriter writer = resp.getWriter();
		
		/* CRIANDO MINHA RESPOSTA EM HTML */
		writer.println("<html><body>");
		
		/* VERIFICANDO SE A MINHA VARIAVEL USUARIO � DIFERENTE DE NUL, CASO SEJA DIFERENTE QUER DIZER QUE O LOGIN
		 * FOI REALIZADO COM SUCESSO, CASO SEJA IGUAL NULO, O LOGIN FALHOU ENT�O ELE N�O TEM DIREITO A 
		 * BUSCAR EMPRESA */
		if(usuario != null) {
			/* CRIANDO O COOKIE ARMAZENDO O EMAIL DO USUARIO LOGADO */
			Cookie cookie = new Cookie("usuario", email);
			resp.addCookie(cookie);
			writer.println("<p>Logado com sucesso</p>");
			writer.println("<a href='index.html'>Buscar empresa</a>'");
		}else {
			writer.println("<p>O login falhou!</p>");
			writer.println("<a href='login.html'>Realizar o login novamente</a>'");
		}
		
		/* FINALIZANDO A MINHA RESPOTA */
		writer.println("</body></html>");
		
		/* SEMPRE FECHAR O WRITER */
		writer.close();
		
	}
}

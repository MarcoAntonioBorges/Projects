package br.com.fiap.gerenciador.empresas.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.andreymasiero.gerenciador.empresas.bean.Usuario;
import com.andreymasiero.gerenciador.empresas.dao.UsuarioDAO;

@WebServlet(urlPatterns = "/cadastro/usuario")
public class CadastroUsuario extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String email = req.getParameter("email");
		String senha = req.getParameter("senha");
		
		PrintWriter writer = resp.getWriter();
		
		Usuario user = new Usuario(email, senha);
		
		UsuarioDAO dao = new UsuarioDAO();
		
		dao.adiciona(user);
		
		writer.println("<html><body>");
		writer.println("<p>Cadastro com sucesso.</p>");
		writer.println("<a href='../login.html'>Realizar login</a>");
		writer.println("</body></html>");
		
	}
	
	
}

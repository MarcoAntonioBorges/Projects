package br.com.mochilao.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.mochilao.beans.Destino;
import br.com.mochilao.conexao.Conexao;

public class DestinoDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public DestinoDAO() throws Exception{
		con = new Conexao().conectar();
	}
	
	public String novoDestino(Destino destino) throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_SPM_DESTINO(CD_DESTINO, NM_DESTINO, DS_DISTANCIA) VALUES (?, ?, ?)");
		
		stmt.setInt(1, destino.getCodigo());
		stmt.setString(2, destino.getLocal());
		stmt.setDouble(3, destino.getDistancia());
		
		stmt.execute();
		
	
		return "Novo destino adicionado com sucesso!";
	}
	
	public void fechar() throws Exception{
		con.close();
	}
	
}

package br.com.mochilao.bo;

import br.com.mochilao.beans.Destino;
import br.com.mochilao.dao.DestinoDAO;

public class DestinoBO {
	
	
	public static String novoDestino(Destino destino) throws Exception{
		if(destino.getLocal().length() < 0) {
			return "Destino invalido";
		}
		if(destino.getLocal().equals(null)) {
			return "Destino invalido";
		}
		if(destino.getDistancia() <= 0) {
			return "Distancia invalida";
		}
		
		
		
		
		DestinoDAO dao = new DestinoDAO();
		
		String msg = dao.novoDestino(destino);
		
		dao.fechar();
		
		return msg;
	}
	
}

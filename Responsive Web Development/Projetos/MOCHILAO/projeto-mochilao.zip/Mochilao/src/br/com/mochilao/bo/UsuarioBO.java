package br.com.mochilao.bo;

import br.com.mochilao.beans.Usuario;
import br.com.mochilao.dao.UsuarioDAO;

public class UsuarioBO {

	public static String novoUsuario(Usuario usuario) throws Exception{
		usuario.setLogin(usuario.getLogin().toUpperCase());
		usuario.setNome(usuario.getNome().toUpperCase());
		
		if(usuario.getLogin().length() < 3) {
			return "Login invalido";
		}
		if(usuario.getNome().length() < 3) {
			return "Nome invalido";
		}
		if(usuario.getSenha().length() < 3) {
			return "Senha muito curta";
		}
		
		UsuarioDAO dao = new UsuarioDAO();
		
		//Verificando se o usuario ja existe
		/*if(!(dao.consultarPorLogin(usuario.getLogin()).getLogin().equals(null))) {
			return "Usuario ja existente";
		}*/
		
		
		
		
	
		String msg = dao.novoUsuario(usuario);
		dao.fechar();
		
		return msg;
	}
	
	
	public static Usuario autenticarUsuario(String login, String senha) throws Exception{
		login = login.toUpperCase();
		
		if(login.length() < 3) {
			return new Usuario();
		}
		if(senha.length() < 3) {
			return new Usuario();
		}
		
		UsuarioDAO dao = new UsuarioDAO();
		
		Usuario usuario = dao.autenticarUsuario(login, senha);
		
		return usuario;
	}
	
}

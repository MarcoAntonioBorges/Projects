package br.com.mochilao.teste;

import java.util.List;

import br.com.mochilao.beans.Mochilao;
import br.com.mochilao.beans.Usuario;
import br.com.mochilao.bo.UsuarioBO;
import br.com.mochilao.dao.MochilaoDAO;

public class TesteAutenticar {

	public static void main(String[] args) {
		try {
			Usuario usuario = UsuarioBO.autenticarUsuario("marco", "123");
			System.out.println(usuario.getCodigo());
			System.out.println(usuario.getNome());
			System.out.println(usuario.getLogin());
			System.out.println(usuario.getSenha());
			System.out.println();
			
			MochilaoDAO dao2 = new MochilaoDAO();
			
			List<Mochilao> mochilas = dao2.consultarMochila(1, "S�O");
			
			for(Mochilao mochilao : mochilas) {
				System.out.println("Usuario: " + mochilao.getUsuario().getLogin());
				System.out.println("Destino: " + mochilao.getDestino().getLocal());
				System.out.println("Data: " + mochilao.getData());
				System.out.println("Acessorios: " + mochilao.getAcessorios());
				System.out.println();
			}
			
			
			dao2.fechar();
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}

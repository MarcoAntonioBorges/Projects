package br.com.mochilao.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.mochilao.beans.Destino;
import br.com.mochilao.beans.Mochilao;
import br.com.mochilao.beans.Usuario;
import br.com.mochilao.dao.DestinoDAO;
import br.com.mochilao.dao.MochilaoDAO;

@WebServlet(urlPatterns = "/cadastro-destino")
public class cadastrarDestino extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		try {
			Usuario usuario = (Usuario) req.getSession(true).getAttribute("usuarioLogado");

			int codigo = (int) ((Math.random() * 190)/2);
			String local = req.getParameter("local");
			double distancia = Double.parseDouble(req.getParameter("distancia"));
			String acessorios = req.getParameter("acessorios");
			String data = req.getParameter("data");
			
			Destino destino = new Destino(codigo, local, distancia);
			
			MochilaoDAO dao = new MochilaoDAO();
			DestinoDAO dao2 = new DestinoDAO();
			
			dao2.novoDestino(destino);
			
			dao.novoMochilao(new Mochilao(codigo, usuario, destino, acessorios, data));
			
			req.getRequestDispatcher("listar-mochilao").forward(req, resp);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		 
		
		
		
		
	}
	
}

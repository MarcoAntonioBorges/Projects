package br.com.mochilao.beans;

public class Destino {
	private int codigo;
	private String local;
	private double distancia;
	
	
	
	public Destino() {
		super();
	}

	public Destino(int codigo, String local, double distancia) {
		super();
		setCodigo(codigo);
		setLocal(local);
		setDistancia(distancia);
	}
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getLocal() {
		return local;
	}
	public void setLocal(String local) {
		this.local = local;
	}
	public double getDistancia() {
		return distancia;
	}
	public void setDistancia(double distancia) {
		this.distancia = distancia;
	}
	
	
	
}

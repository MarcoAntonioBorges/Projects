package br.com.mochilao.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.mochilao.beans.Usuario;
import br.com.mochilao.bo.UsuarioBO;

@WebServlet(urlPatterns = "/cadastro-usuario")
public class CadastrarUsuario extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			String nome = req.getParameter("nome");
			String login = req.getParameter("login");
			String senha = req.getParameter("senha");
			int codigo = (int) (Math.random() * 190);
			
			Usuario usuario = new Usuario(codigo, login, senha, nome);
			
			UsuarioBO.novoUsuario(usuario);
			
			resp.sendRedirect("index.jsp");
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}

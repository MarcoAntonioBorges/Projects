package br.com.mochilao.beans;

public class Mochilao {
	private int codigo;
	private Usuario usuario;
	private Destino destino;
	private String acessorios;
	private String data;
	
	
	
	
	public Mochilao() {
		super();
	}

	public Mochilao(int codigo, Usuario usuario, Destino destino, String acessorios, String data) {
		super();
		setCodigo(codigo);
		setUsuario(usuario);
		setDestino(destino);
		setAcessorios(acessorios);
		setData(data);
	}
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Destino getDestino() {
		return destino;
	}
	public void setDestino(Destino destino) {
		this.destino = destino;
	}
	public String getAcessorios() {
		return acessorios;
	}
	public void setAcessorios(String acessorios) {
		this.acessorios = acessorios;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
	

}

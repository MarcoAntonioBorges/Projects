package br.com.mochilao.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.mochilao.beans.Usuario;
import br.com.mochilao.bo.UsuarioBO;

@WebServlet(urlPatterns = "/autenticar-usuario")
public class AutenticarUsuario extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try{
			
			String login = req.getParameter("login");
			String senha = req.getParameter("senha");
			
			Usuario usuario = UsuarioBO.autenticarUsuario(login, senha);
			
			PrintWriter w = resp.getWriter();
			
			if(usuario.getCodigo()  > 0) {
				HttpSession sessao = req.getSession();
				sessao.setAttribute("usuarioLogado", usuario);
				req.getRequestDispatcher("home.jsp").forward(req, resp);
			}else {
				w.println("<p style='text-transform: uppercase;'>Usuario n�o existe</p>");
			}
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
}

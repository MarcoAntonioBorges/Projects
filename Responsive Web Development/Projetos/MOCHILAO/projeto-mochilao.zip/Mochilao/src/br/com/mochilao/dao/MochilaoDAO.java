package br.com.mochilao.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.mochilao.beans.Destino;
import br.com.mochilao.beans.Mochilao;
import br.com.mochilao.beans.Usuario;
import br.com.mochilao.conexao.Conexao;

public class MochilaoDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public MochilaoDAO() throws Exception{
		con = new Conexao().conectar();
	}
	
	public String novoMochilao(Mochilao mochilao) throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_SPM_MOCHILAO(CD_MOCHILAO, CD_USUARIO, CD_DESTINO, DS_ACESSORIOS, DT_PARTIDA) VALUES (?,?,?,?,?)");
		
		stmt.setInt(1, mochilao.getCodigo());
		stmt.setInt(2, mochilao.getUsuario().getCodigo());
		stmt.setInt(3, mochilao.getDestino().getCodigo());
		stmt.setString(4, mochilao.getAcessorios());
		stmt.setString(5, mochilao.getData());
		
		stmt.execute();
		
		return "Mochila adicionada";
	}
	
	public List<Mochilao> consultarMochila(int codigoU, String local) throws Exception{
		List<Mochilao> mochilao = new ArrayList<Mochilao>();
		
		stmt = con.prepareStatement("SELECT * FROM T_SPM_USUARIO U INNER JOIN T_SPM_MOCHILAO M ON (U.CD_USUARIO = M.CD_USUARIO) INNER JOIN T_SPM_DESTINO D ON (D.CD_DESTINO = M.CD_DESTINO) WHERE U.CD_USUARIO = ? AND D.NM_DESTINO LIKE ?");
		
		stmt.setInt(1, codigoU);
		stmt.setString(2, local+"%");
		
		rs = stmt.executeQuery();
		
		while(rs.next()) {
			mochilao.add(new Mochilao(rs.getInt("CD_MOCHILAO"), new Usuario(rs.getInt("CD_USUARIO"), rs.getString("DS_LOGIN"), rs.getString("DS_SENHA"), rs.getString("NM_COMPLETO")) , new Destino(rs.getInt("CD_DESTINO"), rs.getString("nm_destino"), rs.getDouble("ds_distancia")), rs.getString("DS_ACESSORIOS"), rs.getString("DT_PARTIDA")));
		}
		
		return mochilao;
		
	}
	
	public void fechar() throws Exception{
		con.close();
	}
	
}

package br.com.mochilao.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.mochilao.beans.Mochilao;
import br.com.mochilao.beans.Usuario;
import br.com.mochilao.dao.MochilaoDAO;

@WebServlet(urlPatterns = "/listar-mochilao")
public class ListarMochilao extends HttpServlet{
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		try {
			Usuario usuario = (Usuario) req.getSession(true).getAttribute("usuarioLogado");
			MochilaoDAO dao = new MochilaoDAO();
			String filtro = "";
			List<Mochilao> mochilas = dao.consultarMochila(usuario.getCodigo(), filtro);
			
			
			PrintWriter w = resp.getWriter();
			
			/*
			for(Mochilao mochila : mochilas) {
				w.println(mochila.getCodigo());
				w.println(mochila.getUsuario().getNome());
				w.println(mochila.getDestino().getLocal());
				w.println(mochila.getData());
			}
			*/
			
			req.setAttribute("mochilao", mochilas);
			req.getRequestDispatcher("listar_mochilas.jsp").forward(req, resp);
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
}

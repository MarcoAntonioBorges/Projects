package br.com.mochilao.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import br.com.mochilao.beans.Usuario;
import br.com.mochilao.conexao.Conexao;

public class UsuarioDAO {
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	
	public UsuarioDAO() throws Exception{
		con = new Conexao().conectar();
	}
	
	public String novoUsuario(Usuario usuario) throws Exception{
		stmt = con.prepareStatement("INSERT INTO T_SPM_USUARIO(CD_USUARIO, NM_COMPLETO, DS_LOGIN, DS_SENHA) VALUES (?, ?, ?, ?)");
		
		stmt.setInt(1, usuario.getCodigo());
		stmt.setString(2, usuario.getNome());
		stmt.setString(3, usuario.getLogin());
		stmt.setString(4, usuario.getSenha());
		
		stmt.execute();
		
		
		return "Cadastro realizado com sucesso!";
	}
	
	
	public Usuario autenticarUsuario(String login, String senha) throws Exception{
		stmt = con.prepareStatement("SELECT * FROM T_SPM_USUARIO WHERE DS_LOGIN = ? AND DS_SENHA = ?");
		
		stmt.setString(1, login);
		stmt.setString(2, senha);
	
		rs = stmt.executeQuery();
		
		if(rs.next()) {
			return new Usuario(rs.getInt("CD_USUARIO"), rs.getString("DS_LOGIN"), rs.getString("DS_SENHA"), rs.getString("NM_COMPLETO"));
		}else {
			return new Usuario();
		}
	
	}
	
	public Usuario consultarPorLogin(String login) throws Exception{
		stmt = con.prepareStatement("SELECT * FROM T_SPM_USUARIO WHERE DS_LOGIN = ?");
		stmt.setString(1, login);
		
		rs = stmt.executeQuery();
		
		if(rs.next()) {
			return new Usuario(rs.getInt("CD_USUARIO"), rs.getString("DS_LOGIN"), rs.getString("DS_SENHA"), rs.getString("NM_COMPLETO"));
		}else {
			return new Usuario();
		}
	}
	
	public void fechar() throws Exception{
		con.close();
	}
	
}

import java.text.DecimalFormat;
import java.util.Scanner;

public class Ex_04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// CRIANDO AS VARIVEIRA E INICIALIZANDO-AS
		int total_idade=0, cont=0, idade=1, op_a=0, op_b=0, op_c=0, op_d=0, op_e=0;
		char op;
		double media_idade;
		
		
		// INST�NCIANDO A CLASSE SCANNER PARA PEGAR O QUE O USUARIO DIGITAR
		Scanner teclado = new Scanner(System.in);
		
		// INSTANCIA A CLASSE FORMAT PARA FORMATA O RESULTADO DE NUMEROS DECIMAIS
		DecimalFormat formatacao = new DecimalFormat("##0.00");
		
		while(idade!=0) {
			System.out.print("Informe sua idade: ");
			idade = teclado.nextInt();
			
			if (idade!=0) {			
				// CRIANDO UM MENU PARA O USUARIO PODER ESCOLHER A OPNI�O DELE
				System.out.println("====== QUESTIONARIO ======");
				System.out.println("A - �timo");
				System.out.println("B - Bom");
				System.out.println("C - Regular");
				System.out.println("D - Ruim");
				System.out.println("E - P�ssimo");
				System.out.println("==========================");
				System.out.print("Informe sua opni�o: ");
				// PEGANDO A PRIMEIRA LETRA QUE O USUARIO DIGITOU E DEIXANDO ELA EM CAIXA ALTA
				op = teclado.next().toUpperCase().charAt(0);
				
				// VALIANDO O QUE O USUARIO DIGITOU
				while(op!='A' && op!='B' && op!='C' && op!='D' && op!='E' && op!='0') {
					System.out.print("Informe sua opni�o novamente: ");
					op = teclado.next().toUpperCase().charAt(0);
				}
				
				// QUEBRA DE LINHA PARA CADA OPNI�O
				System.out.println("");
				
				switch (op) {
				case 'A': 
					op_a++;
					break;
				case 'B':
					op_b++;
					break;
				case 'C': 
					op_c++;
					break;
				case 'D': 
					op_d++;
					break;
				case 'E':
					op_e++;
					break;
				}

				// PROCESSAMENTO
				total_idade = total_idade + idade;
				cont++;

			}
		
		}
		media_idade = (double) total_idade/cont;
		
		// SA�DAS
		
		System.out.println("Quantidade das pessoas que responderam o question�rio: " + cont);
		System.out.println("M�dia das idades das pessoas que responderam o question�rio: " + media_idade);
		System.out.println("Porcentagem da opni�o A: " + formatacao.format((double) op_a/cont * 100) + "%");
		System.out.println("Porcentagem da opni�o B: " + formatacao.format((double) op_b/cont * 100) + "%");
		System.out.println("Porcentagem da opni�o C: " + formatacao.format((double) op_c/cont * 100) + "%");
		System.out.println("Porcentagem da opni�o D: " + formatacao.format((double) op_d/cont * 100) + "%");
		System.out.println("Porcentagem da opni�o E: " + formatacao.format((double) op_e/cont * 100) + "%");
	}

}

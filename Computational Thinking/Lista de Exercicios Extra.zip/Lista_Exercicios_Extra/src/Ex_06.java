import java.text.DecimalFormat;
import java.util.Scanner;

public class Ex_06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// CRIANDO AS VARIVEIRA E INICIALIZANDO-AS
		int canal=1, total_canal=0, cont_4=0, cont_5=0, cont_7=0, cont_12=0, qtd_pessoas=0;
		double total_cont_4=0, total_cont_5=0, total_cont_7=0, total_cont_12=0;
		
		
		// INST�NCIANDO A CLASSE SCANNER PARA PEGAR O QUE O USUARIO DIGITAR
		Scanner teclado = new Scanner(System.in);
		
		// INSTANCIA A CLASSE FORMAT PARA FORMATA O RESULTADO DE NUMEROS DECIMAIS
		DecimalFormat formatacao = new DecimalFormat("##0.00");
		
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (WHILE) ////////////
		
		// 1� - TER UMA VARIVEL DE CONTROLE PARA CONTROLAR A REPETI��O;
		// 2� - ENQUANTO O CANAL N�O FOR DIFERENTE DE 0 ELE CONTINUAR� A REPETI��O 
		// 3� - N�O NECESSITA DE INCREMENTO NESSE CASO
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (WHILE) ////////////
		while(canal!=0) {
			
			System.out.print("Digite o numero do canal: ");
			canal = teclado.nextInt();
			
			
			// VALIDANDO O QUE O USUARIO DIGITOU
			while(canal!=4 && canal!=5 && canal!=7 && canal!=12 && canal!=0) {
				System.out.print("Digite novamente o numero do canal: ");
				canal = teclado.nextInt();
			}
			
			// VERIFICANDO SE O CANAL � DIFERENTE DE 0
			if(canal!=0) {
				// PEGANDO OS DADOS
				System.out.print("Digite a qtd de pessoas que estavam  assistindo o canal: ");
				qtd_pessoas = teclado.nextInt();
			
				switch (canal) {
				case 4:
					cont_4 += qtd_pessoas;
					break;
				case 5:
					cont_5 += qtd_pessoas;
					break;
				case 7:
					cont_7 += qtd_pessoas;
					break;
				case 12:
					cont_12 += qtd_pessoas;
					break;
				
				}
			}
		}
		
		//PROCESSAMENTO
		
		total_canal = cont_4 + cont_5 + cont_7 + cont_12;
		total_cont_4 = (double) cont_4 / total_canal * 100;
		total_cont_5 = (double) cont_5 / total_canal * 100;
		total_cont_7 = (double) cont_7 / total_canal * 100;
		total_cont_12 = (double) cont_12 / total_canal * 100;
		
		// SA�DAS
		
		System.out.println();
		
		System.out.println("Porcentagem de espectadores do canal 4: " + formatacao.format(total_cont_4) + "%");
		System.out.println("Porcentagem de espectadores do canal 5: " + formatacao.format(total_cont_5) + "%");
		System.out.println("Porcentagem de espectadores do canal 7: " + formatacao.format(total_cont_7) + "%");
		System.out.println("Porcentagem de espectadores do canal 12: " + formatacao.format(total_cont_12) + "%");
	}

}

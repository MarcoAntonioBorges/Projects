import java.util.Scanner;

public class Ex_01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		// DECLARANDO AS VARIAVEIS
		int idade=0, faixa_total, faixa_1=0, faixa_2=0, faixa_3=0, faixa_4=0, faixa_5=0;
		double faixa_1_total=0;
		
		//INST�NCIA A CLASSE SCANNER PARA PODER GUARDA O QUE O USUARIO FOR DIGITAR
		Scanner teclado = new Scanner(System.in);
		
		// CRIANDO UM LA�O DE REPETI��O 
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (FOR) ////////////
		
		// 1� - CRIANDO A VARIAVEL i COMO INTEIRA E INICIANDO COM O VALOR 0;
		// 2� - PERGUNTANDO A CADA RODADA SE i � MAIOR QUE 20; 
		// 3� - SEMPRE AP�S UMA RODADA, i INCREMENTA i = i + 1
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (FOR) ////////////
		
		for(int i=0; i < 20; i++) {
			// PEDINDO AO USUARIO AS INFORMA��ES
			System.out.println("Digite sua idade: ");
			idade = teclado.nextInt();
			
			// VERIFICANDO SE IDADE DIGITADO PELO USUARIO � MENOR OU IGUAL A 15
			if (idade <= 15) {
				// CONTADOR, PARA PODER CONTAR QUANTAS PESSOAS � DA 1� FAIXA ET�RIA
				faixa_1++;
			}else if(idade <= 30) {
				faixa_2++;
			}else if(idade <= 45) {
				faixa_3++;
			}else if(idade <= 60) {
				faixa_4++;
			}else {
				faixa_5++;
			}
			
		}
		// GUARDANDO TODAS AS PESSOAS DE TODAS AS FAIXA ET�RIAS NA VARIAVEL 
		faixa_total = faixa_1 + faixa_2 + faixa_3 + faixa_4 + faixa_5;
		// CALCULANDO A PORCENTAGEM DA 1� FAIXA ET�RIA EM RELA��O AO TOTAL
		faixa_1_total = (double) faixa_1/faixa_total * 100;
		
		// SA�DAS
		System.out.println("Total de pessoas na 1� Faixa Et�ria: " + faixa_1);
		System.out.println("Total de pessoas na 2� Faixa Et�ria: " + faixa_2);
		System.out.println("Total de pessoas na 3� Faixa Et�ria: " + faixa_3);
		System.out.println("Total de pessoas na 4� Faixa Et�ria: " + faixa_4);
		System.out.println("Total de pessoas na 5� Faixa Et�ria: " + faixa_5);
		System.out.println("Porcentagem da 1� Faixa Et�ria em rela��o ao total das Faixas Et�rias: " + faixa_1_total + "%");
	}

}

import java.text.DecimalFormat;
import java.util.Scanner;

public class Ex_03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// CRIANDO AS VARIVEIRA E INICIALIZANDO-AS
		int rm=0, alunos_aprovados=0, alunos_reprovados=0, n_aulas_frequentadas=0, alunos_reprovados_frequencia=0;
		double nota_1, nota_2, nota_3, total_nota;
		String avaliacao;
		
		// INST�NCIANDO A CLASSE SCANNER PARA PEGAR O QUE O USUARIO DIGITAR
		Scanner teclado = new Scanner(System.in);
		
		// INSTANCIA A CLASSE FORMAT PARA FORMATA O RESULTADO DE NUMEROS DECIMAIS
		DecimalFormat formatacao = new DecimalFormat("##0.00");
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (FOR) ////////////
		
		// 1� - CRIANDO A VARIAVEL i COMO INTEIRA E INICIANDO COM O VALOR 0;
		// 2� - PERGUNTANDO A CADA RODADA SE i � MAIOR QUE 10; 
		// 3� - SEMPRE AP�S UMA RODADA, i INCREMENTA i = i + 1
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (FOR) ///////////
		
		for (int i = 0; i < 3; i++) {
			// COLETANDO OS DADOS DO USUARIO
			System.out.println("Digite o RM: ");
			rm = teclado.nextInt();
			
			System.out.println("Digite a 1� Nota; ");
			nota_1 = teclado.nextDouble();
			
			System.out.println("Digite a 2� Nota: ");
			nota_2 = teclado.nextDouble();

			System.out.println("Digite a 3� Nota: ");
			nota_3 = teclado.nextDouble();
		
			System.out.println("Digite a frequencia: ");
			n_aulas_frequentadas = teclado.nextInt();
			
			// FAZENDO A M�DIA ARITM�TICA ENTRE AS NOTAS
			total_nota = (nota_1 + nota_2 + nota_3) / 3;
			
			
			// ESTRUTURA DE CONDI��O
			if(n_aulas_frequentadas < 40) {
				// FAZENDO INCREMENTO
				alunos_reprovados++;
				alunos_reprovados_frequencia++;
				//ATRIBUINDO UMA STRING NA VARIAVEL
				avaliacao = "REPROVADO POR FREQUENCIA";
			}else if (total_nota < 6) {
				alunos_reprovados++;
				avaliacao = "REPROVADO";
			}else {
				alunos_aprovados++;
				avaliacao = "APROVADO";
			}
			
			// SA�DA PARA CADA ALUNO
			System.out.println("========== " + avaliacao + " ==========");
			System.out.println("RM: " + rm);
			System.out.println("Nota Final: " + formatacao.format(total_nota));
			System.out.println("Frequencia: " + n_aulas_frequentadas);
			
			// SEPARA��O ENTRE CADA ALUNO
			System.out.println();
		}
		
		// SA�DAS FINAIS
		System.out.println("Total Aprovados: " + alunos_aprovados);
		System.out.println("Total Reprovados: " + alunos_reprovados);
		System.out.println("Total Reprovados por Frequencia: " + alunos_reprovados_frequencia);
	}

}

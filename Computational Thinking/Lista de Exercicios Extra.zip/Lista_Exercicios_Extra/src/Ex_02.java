import java.text.DecimalFormat;
import java.util.Scanner;

public class Ex_02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// DECLARANDO AS VARIAVEIS E INICIALIZANDO-AS
		int cont=1, voto_total=0, voto_cand1=0, voto_cand2=0, voto_cand3=0, voto_cand4=0, voto_nulo=0, voto_branco=0;
		
		// INST�NCIANDO A CLASSE SCANNER PARA PEGAR O QUE O USUARIO DIGITAR
		Scanner teclado = new Scanner(System.in);
		
		// INSTANCIA A CLASSE FORMAT PARA FORMATA O RESULTADO DE NUMEROS DECIMAIS
		DecimalFormat formatacao = new DecimalFormat("##0.00");
		
		// CRIANDO UM LA�O DE REPETI��O (WHILE)
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (WHILE) ////////////
		
		// 1� - TER UMA VARIVEL DE CONTROLE PARA CONTROLAR A REPETI��O;
		// 2� - PERGUNTAR A CADA VOLTA SE A VARIAVEL SASTIFAZ A CONDI��O, NESSE CASO PERGUNTANDO SE cont � DIFERENTE DE 0; 
		// 3� - N�O NECESSITA DE INCREMENTO NESSE CASO
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (WHILE) ////////////
		while(cont!=0) {
			// PEGANDO OS DADOS DO USUARIO
			System.out.println("Digite o C�digo do candidato: ");	
			cont = teclado.nextInt();
		
			// VALIDANDO O QUE O USUARIO DIGITOU
			while(cont!=1 && cont!=2 && cont!=3 && cont!=4 && cont!=5 && cont!=6 && cont!=0) {
				System.out.println("Digite novamente o C�digo do candidato: ");	
				cont = teclado.nextInt();
			}
					
			// 
			switch (cont) {
			case 1:
				voto_cand1++;
				break;
			case 2:
				voto_cand2++;
				break;
			case 3:
				voto_cand3++;
				break;
			case 4:
				voto_cand4++;
				break;
			case 5: 
				voto_nulo++;
				break;
			case 6: 
				voto_branco++;
				break;
			}
		}
		
		// SOMANDO TODOS OS VOTOS
		voto_total = voto_cand1 + voto_cand2 + voto_cand3 + voto_cand4 + voto_nulo + voto_branco;
		
		// SA�DAS
		System.out.println("Total de votos para o 1� candidato: " + voto_cand1);
		System.out.println("Total de votos para o 2� candidato: " + voto_cand2);
		System.out.println("Total de votos para o 3� candidato: " + voto_cand3);
		System.out.println("Total de votos para o 4� candidato: " + voto_cand4);
		System.out.println("Total de votos nulos: " + voto_nulo);
		System.out.println("Total de votos brancos: " + voto_branco);
		System.out.println("Porcentagem de votos nulos em rela��o ao total de votos: " + formatacao.format((double) voto_branco/voto_total * 100) + "%");
		System.out.println("Porcentagem de votos brancos em rela��o ao total de votos: " + formatacao.format((double) voto_nulo/voto_total * 100) + "%");
	}

}

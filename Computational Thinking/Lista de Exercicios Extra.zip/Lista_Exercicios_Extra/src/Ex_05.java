import java.text.DecimalFormat;
import java.util.Scanner;

public class Ex_05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// DECLARANDO AS VARIAVEIS E INICIALIZANDO-AS
		int cod=1, tipo_conta=0, cont_cliente=0;
		double investimento=0, juros, rendimento_mensal=0;
		
		double	total_investido_p=0, total_juros_p=0, total_investido_pp=0, total_juros_pp=0, total_investido_frf=0, total_juros_frf=0;
		
		// INST�NCIANDO A CLASSE SCANNER PARA PEGAR O QUE O USUARIO DIGITAR
		Scanner teclado = new Scanner(System.in);
		
		// INSTANCIA A CLASSE FORMAT PARA FORMATA O RESULTADO DE NUMEROS DECIMAIS
		DecimalFormat formatacao = new DecimalFormat("##0.00");
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (WHILE) ////////////
		
		// 1� - TER UMA VARIVEL DE CONTROLE PARA CONTROLAR A REPETI��O;
		// 2� - ENQUANTO CODIGO N�O FOR DIFERENTE DE 0 ELE CONTINUAR� A REPETI��O 
		// 3� - N�O NECESSITA DE INCREMENTO NESSE CASO
		
		//////////// ESTRUTURA DO LA�O DE REPETI��O (WHILE) ////////////
		while(cod!=0) {
			// COLETANDO OS DADOS = ENTRADA
			System.out.print("Digite o codigo do cliente: ");
			cod = teclado.nextInt();
			if (cod!=0) {
				
				System.out.print("Digite o Tipo da conta: ");
				tipo_conta = teclado.nextInt();
				
				// VALIDA��O, ENQUANTO O TIPO DE CONTA FOR MENOR QUE 0 OU MAIOR QUE 3, 
				//ELE CONTINUAR� FAZENDO ESSA REPETI��O, OU SEJA O USUARIO FICAR� PRESO NESSA PARTE 
				//SE N�O SASTIFAZER A CONDI��O QUE � DIGITAR UM TIPO DE CONTA V�LIDO
				while(tipo_conta < 1 || tipo_conta > 3) {
					System.out.print("Digite novamente o Tipo da conta: ");
					tipo_conta = teclado.nextInt();
				}
				
				System.out.print("Valor do investimento, R$");
				investimento = teclado.nextDouble(); 
				
				
				// PROCESSAMENTO //
				// ESTRUTURA SWITCH CASE
				// ESTOU PEGANDO A INFORMA��O QUE O USUARIO DIGITOU E VENDO SE O 
				//TIPO DA CONTA FOR CASO 1, ELE APLICAR� UM PROCESSAMENTO ESPECIF�CO, 
				//ASSIM SUCESSIVAMENTE, TANTO PARA O CASO 2 E CASO 3, 
				//TODOS TEM UM PROCESSAMENTO ESPECIFICO 
				// PODERIA SER FEITO ULTILIZANDO IF ENCADEADO
				switch (tipo_conta) {
				case 1:
					juros = 0.015;
					rendimento_mensal = investimento * juros;
					total_investido_p += investimento;
					total_juros_p = total_investido_p * juros;
					break;
				case 2:
					juros = 0.02;
					rendimento_mensal = investimento * juros;
					total_investido_pp += investimento;
					total_juros_pp = total_investido_pp * juros;
					break;
				case 3:
					juros = 0.04;
					rendimento_mensal = investimento * juros;
					total_investido_frf += investimento;
					total_juros_frf = total_investido_frf * juros;
					break;
				}
				
				System.out.println("Rendimento mensal, R$" + formatacao.format(rendimento_mensal));
				System.out.println();
				cont_cliente++;
			}
			
		}
		
		// SA�DAS
		
		System.out.println();
		System.out.println("====== RESULTADOS ======");
		System.out.println();
		// TOTAL DE CLIENTES
		System.out.println("Total de clientes: " + cont_cliente);
		
		// POUPAN�A
		System.out.println("Total investido em poupan�a, R$" + formatacao.format(total_investido_p));
		System.out.println("Total de juros em poupan�a, R$" + formatacao.format(total_juros_p));
	
		// POUPAN�A PLUS
		System.out.println("Total investido em poupan�a plus, R$" + formatacao.format(total_investido_pp));
		System.out.println("Total de juros em poupan�a plus, R$" + formatacao.format(total_juros_pp));
	
		//Fundos de Renda Fixa
		System.out.println("Total investido em Fundos de Renda Fixa, R$" + formatacao.format(total_investido_frf));
		System.out.println("Total de juros em Fundos de Renda Fixa, R$" + formatacao.format(total_juros_frf));
		
	}

}
